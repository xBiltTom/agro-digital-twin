management.sch: written by SWAT+ editor v3.2.2-dev on 2026-09-12 17:12 
name                                       numb_ops  numb_auto            op_typ       mon       day        hu_sch          op_data1          op_data2      op_data3  
agrl_rot                          0          1  
                                                   pl_hv_summer1   agrl  
corn_rot                          0          1  
                                                   pl_hv_summer1_corn   corn
